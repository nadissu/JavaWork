package HMRS.hmrs.core.adapters.concretes;

public class CloudinaryAdapterService {

}
