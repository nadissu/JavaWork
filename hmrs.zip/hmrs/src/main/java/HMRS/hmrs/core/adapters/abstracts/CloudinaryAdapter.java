package HMRS.hmrs.core.adapters.abstracts;

import java.io.IOException;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import HMRS.hmrs.core.utilities.results.DataResult;

public interface CloudinaryAdapter {
	DataResult<Map<String, String>> upload(MultipartFile file);
	DataResult<Map>delete(String id) throws IOException;
}
