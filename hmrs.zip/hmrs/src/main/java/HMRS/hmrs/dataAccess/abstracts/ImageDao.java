package HMRS.hmrs.dataAccess.abstracts;

import org.springframework.data.jpa.repository.JpaRepository;

import HMRS.hmrs.entities.concretes.Image;

public interface ImageDao extends JpaRepository<Image, Integer> {

}
