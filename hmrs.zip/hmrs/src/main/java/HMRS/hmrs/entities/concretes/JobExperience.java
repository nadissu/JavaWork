package HMRS.hmrs.entities.concretes;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name="job_experiences")

public class JobExperience {
	  	@Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name="id")
	    private int id;
	  	
	  	@Column(name="workplace_name")
	  	private String workplaceName;
	  	
	  	@Column(name="position")
	  	private String position;
	  	
	  	@Column(name="start_date")
	  	private LocalDate startDate;
	  	
	  	@Column(name="finish_date")
	  	private LocalDate finishDate;
	  	
	  	@Column(name="is_available")
	  	private boolean isAvailable;
	  	
	  	@Column(name="description")
	  	private String description;
	  	
	  	@ManyToOne(fetch = FetchType.LAZY, cascade={ CascadeType.PERSIST, CascadeType.MERGE })
		@JoinColumn(name="candidate_id", insertable=false, updatable=false)
		private Candidate candidate;
		
		@ManyToOne(fetch = FetchType.LAZY, cascade={ CascadeType.PERSIST, CascadeType.MERGE })
		@JoinColumn(name="education_id", insertable=false, updatable=false)
		private Education education;
		
		@ManyToOne(fetch = FetchType.LAZY, cascade={ CascadeType.PERSIST, CascadeType.MERGE })
		@JoinColumn(name="account_id", insertable=false, updatable=false)
		private Account account;
		
		@ManyToOne(fetch = FetchType.LAZY, cascade={ CascadeType.PERSIST, CascadeType.MERGE })
		@JoinColumn(name="foreign_language_id", insertable=false, updatable=false)
		private ForeignLanguage foreignLanguage;
		
		@ManyToOne(fetch = FetchType.LAZY, cascade={ CascadeType.PERSIST, CascadeType.MERGE })
		@JoinColumn(name="programming_language_id", insertable=false, updatable=false)
		private ProgrammingLanguage programmingLanguage;
		
		@ManyToOne(fetch = FetchType.LAZY, cascade={ CascadeType.PERSIST, CascadeType.MERGE })
		@JoinColumn(name="image_id", insertable=false, updatable=false)
		private Image image;
		
		
		
}
