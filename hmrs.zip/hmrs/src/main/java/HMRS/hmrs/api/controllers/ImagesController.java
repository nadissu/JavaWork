package HMRS.hmrs.api.controllers;

public class ImagesController {

}
