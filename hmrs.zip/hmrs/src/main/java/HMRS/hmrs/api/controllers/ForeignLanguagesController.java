package HMRS.hmrs.api.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import HMRS.hmrs.business.abstracts.ForeignLanguageService;
import HMRS.hmrs.core.utilities.constants.ApiPaths;
import HMRS.hmrs.core.utilities.results.DataResult;
import HMRS.hmrs.core.utilities.results.Result;
import HMRS.hmrs.entities.concretes.ForeignLanguage;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(ApiPaths.ForeignLanguage.CTRL)
public class ForeignLanguagesController {
	@Autowired
	
	private ForeignLanguageService foreignLanguageService;

	public ForeignLanguagesController(ForeignLanguageService foreignLanguageService) {
		super();
		this.foreignLanguageService = foreignLanguageService;
	}
	
	@GetMapping("/getall")
	@ApiOperation(value = "Foreign Language Get All Operation", response = ForeignLanguage.class)
	public DataResult<List<ForeignLanguage>> getAll(){
		return this.foreignLanguageService.getAll();
	}
	@PostMapping("/")
	@ApiOperation(value="Foreign Language Add Operation",response=ForeignLanguage.class)
	public Result add(@RequestBody ForeignLanguage foreignLanguage){
		return this.foreignLanguageService.add(foreignLanguage);
	}
}

