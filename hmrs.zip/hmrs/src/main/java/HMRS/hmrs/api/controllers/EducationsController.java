package HMRS.hmrs.api.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import HMRS.hmrs.business.abstracts.EducationService;
import HMRS.hmrs.core.utilities.constants.ApiPaths;
import HMRS.hmrs.entities.concretes.Education;
import io.swagger.annotations.Api;

@RestController
@RequestMapping(ApiPaths.EducationCtrl.CTRL)
@Api(value = "School APIs")
public class EducationsController {
	
	@Autowired
	EducationService educationService;
	

	public EducationsController(EducationService educationService) {
		super();
		this.educationService = educationService;
	}

	
	
	 @GetMapping("/getall")
	    public ResponseEntity<?> getAll (){
	        var result = this.educationService.getAll();
	        if (!result.isSuccess()){
	            return ResponseEntity.badRequest().body(result);
	        }
	        return ResponseEntity.ok(result);
	    }

	    @PostMapping("/add")
	    public ResponseEntity<?> add(@RequestBody Education school){
	        var result = this.educationService.add(school);
	        if (!result.isSuccess()){
	            return ResponseEntity.badRequest().body(result);
	        }
	        return ResponseEntity.ok(result);
	    }

}
