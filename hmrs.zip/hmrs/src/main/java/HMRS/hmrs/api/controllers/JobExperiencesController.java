package HMRS.hmrs.api.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;

import HMRS.hmrs.business.abstracts.JobExperienceService;
import HMRS.hmrs.core.utilities.constants.ApiPaths;
import HMRS.hmrs.entities.concretes.JobExperience;
import io.swagger.annotations.Api;

@RestController
@RequestMapping(ApiPaths.JobExperience.CTRL)
@Api(value = "JobExperience APIs")
public class JobExperiencesController {
	
	@Autowired
	
    private JobExperienceService jobExperienceService;

	public JobExperiencesController(JobExperienceService jobExperienceService) {
		super();
		this.jobExperienceService = jobExperienceService;
	}
	
	  @GetMapping("/getall")
	    public ResponseEntity<?> getAll(){
	        var result = this.jobExperienceService.getAll();
	        if (!result.isSuccess()){
	            return ResponseEntity.badRequest().body(result);
	        }
	        return ResponseEntity.ok(result);
	    }
	  @PostMapping("/add")
	    public ResponseEntity<?> add(@RequestBody JobExperience jobExperience){
		  
	        var result = this.jobExperienceService.add(jobExperience);
	        if (!result.isSuccess()){
	            return ResponseEntity.badRequest().body(result);
	        }
	        return ResponseEntity.ok(result);
	    }
	
	

}
