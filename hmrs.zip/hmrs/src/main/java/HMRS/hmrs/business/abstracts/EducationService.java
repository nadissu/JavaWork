package HMRS.hmrs.business.abstracts;


import java.util.List;

import HMRS.hmrs.core.utilities.results.DataResult;
import HMRS.hmrs.core.utilities.results.Result;
import HMRS.hmrs.entities.concretes.Education;

public interface EducationService {
	DataResult<List<Education>> getAll();
	DataResult<Education> add(Education education);
	DataResult<List<Education>> getByIsFinishFalseOrderByFinishDate();
	DataResult<List<Education>> getByIsFinishTrueOrderByFinishDate();

}
