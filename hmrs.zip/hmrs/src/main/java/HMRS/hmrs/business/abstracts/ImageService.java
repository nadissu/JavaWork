package HMRS.hmrs.business.abstracts;

public interface ImageService {

}
