package HMRS.hmrs.business.concretes;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import HMRS.hmrs.business.abstracts.EducationService;
import HMRS.hmrs.core.utilities.results.DataResult;
import HMRS.hmrs.core.utilities.results.ErrorDataResult;
import HMRS.hmrs.core.utilities.results.SuccessDataResult;
import HMRS.hmrs.dataAccess.abstracts.EducationDao;
import HMRS.hmrs.entities.concretes.Education;
@Service
public class EducationManager implements EducationService{
	
	@Autowired
	EducationDao educationDao;

	public EducationManager(EducationDao educationDao) {
		super();
		this.educationDao = educationDao;
	}

	@Override
	public DataResult<List<Education>> getAll() {
		 Sort sort = Sort.by(Sort.Direction.DESC,"finishDate");
		return new SuccessDataResult<List<Education>>(this.educationDao.findAll(sort),"School Are Listed");
	}

	@Override
	public DataResult<Education> add(Education education) {
		if(education.isFinish()==true) {
			if (education.getFinishDate()== null) {
				return new ErrorDataResult<Education>("Mezuniyet Yılı Boş Geçilemez.");
			} 
		}
		return new SuccessDataResult<>(this.educationDao.save(education),"School Data Is Added ");
	}

	@Override
	public DataResult<List<Education>> getByIsFinishFalseOrderByFinishDate() {
		return new SuccessDataResult<List<Education>>(this.educationDao.getByIsFinishFalseOrderByFinishDate(), "Devam Ediyor");
	}

	@Override
	public DataResult<List<Education>> getByIsFinishTrueOrderByFinishDate() {
		return new SuccessDataResult<List<Education>>(this.educationDao.getByIsFinishTrueOrderByFinishDate(),"Mezuniyet Yılı Boş Geçilemez");
	}

}
