package HMRS.hmrs.business.concretes;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import HMRS.hmrs.business.abstracts.JobExperienceService;
import HMRS.hmrs.core.utilities.results.DataResult;
import HMRS.hmrs.core.utilities.results.ErrorDataResult;
import HMRS.hmrs.core.utilities.results.SuccessDataResult;
import HMRS.hmrs.dataAccess.abstracts.JobExperienceDao;
import HMRS.hmrs.entities.concretes.Education;
import HMRS.hmrs.entities.concretes.JobExperience;

@Service
public class JobExperienceManager implements JobExperienceService{
	@Autowired
	private JobExperienceDao jobExperienceDao;
	
	

	public JobExperienceManager(JobExperienceDao jobExperienceDao) {
		super();
		this.jobExperienceDao = jobExperienceDao;
	}

	@Override
	public DataResult<List<JobExperience>> getAll() {
		Sort sort = Sort.by(Sort.Direction.DESC,"finishDate");
		return new SuccessDataResult<List<JobExperience>>(this.jobExperienceDao.findAll(sort),"Job Experience Are Listed");
	}

	@Override
	public DataResult<JobExperience> add(JobExperience jobExperience) {
		if (jobExperience.isAvailable()) {
			return new SuccessDataResult<JobExperience>("İşten Çıkış Tarihinizi Boş Geçebilirsiniz.");
		}
		return new SuccessDataResult<>(this.jobExperienceDao.save(jobExperience));
	}

	@Override
	public DataResult<List<JobExperience>> getByIsAvailableTrueOrderByFinishDate() {
		return new SuccessDataResult<List<JobExperience>>(this.jobExperienceDao.getByIsAvailableTrueOrderByFinishDate(), "Devam Ediyor");
	}

}
