package HMRS.hmrs.business.concretes;

import HMRS.hmrs.business.abstracts.ImageService;

public class ImageManager implements ImageService{

}
